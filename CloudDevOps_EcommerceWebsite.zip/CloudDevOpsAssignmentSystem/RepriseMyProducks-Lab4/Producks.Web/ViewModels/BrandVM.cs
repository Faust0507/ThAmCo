﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Producks.Web.ViewModels
{
    public class BrandVM
    {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
    }
}
