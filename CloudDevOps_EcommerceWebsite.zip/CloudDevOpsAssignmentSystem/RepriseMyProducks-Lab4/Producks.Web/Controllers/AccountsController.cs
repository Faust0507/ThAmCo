﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Producks.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using Producks.Web.Models;

namespace Producks.Web.Controllers
{
    public class AccountsController : Controller
    {
        private readonly StoreDb _context;

        public AccountsController(StoreDb context)
        {
            _context = context;
        }

        //login user
        public async Task<IActionResult> Login()
        {
            if (HttpContext.Session.GetString("userid") == null)
            {
                return View();
            }

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("Email,Password,Role")] Account account)
        {
            Debug.WriteLine("test role:" + account.Role);

            string loginEmail = account.Email;
            string loginPassword = account.Password;
            string loginRole = account.Role;

            if (ModelState.IsValid)
            {
                //var password = staff.StaffPassword;
                if (loginRole.Equals("Staff") || loginRole.Equals("Management"))
                {
                    var data = await _context.Staffs.Where(s => s.StaffEmail.Equals(loginEmail) && s.StaffPassword.Equals(loginPassword) && s.StaffRole.Equals(loginRole)).ToListAsync();
                    
                    if (data.Count() > 0)
                    {
                        //add session
                        HttpContext.Session.SetString("name", data.FirstOrDefault().StaffName);
                        HttpContext.Session.SetString("email", data.FirstOrDefault().StaffEmail);
                        var userId = data.FirstOrDefault().StaffId;
                        HttpContext.Session.SetString("userid", userId.ToString());
                        HttpContext.Session.SetString("role", data.FirstOrDefault().StaffRole);

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        TempData["tempdata"] = "Invalid Email or Password for " + loginRole + "!";
                        return RedirectToAction("Login");
                    }
                }
                else
                {
                    var custdata = await _context.Customers.Where(c => c.CustEmail.Equals(loginEmail) && c.CustPassword.Equals(loginPassword)).ToListAsync();
                    //var password = customer.CustPassword;

                    if (custdata.Count() > 0)
                    {
                        //add session
                        HttpContext.Session.SetString("name", custdata.FirstOrDefault().CustName);
                        HttpContext.Session.SetString("email", custdata.FirstOrDefault().CustEmail);
                        var userId = custdata.FirstOrDefault().Id;
                        HttpContext.Session.SetString("userid", userId.ToString());
                        HttpContext.Session.SetString("role", "Customer");

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        TempData["tempdata"] = "Invalid Email or Password for Customer!";
                        return RedirectToAction("Login");
                    }

                }
            }
            return View();
        }

        public ActionResult Logout()
        {
            HttpContext.Session.Clear();//remove session
            return RedirectToAction("Login");
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .Include(o => o.Orders)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: OrderDetails/OrdDetails/5
        public async Task<IActionResult> OrdDetails(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders
                .Include(od => od.OrderDetails)
                .ThenInclude(p => p.Product)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CustName,CustEmail,CustPassword,Address,Contact")] Customer customer)
        {
            if (id != customer.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Details), new { id = id });
            }
            return View(customer);
        }

        // GET: Accounts/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Accounts/Register
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register([Bind("Id,CustName,CustEmail,CustPassword,Address,Contact")] Customer customer)
        {
            var checkEmail = _context.Customers.Where(s => s.CustEmail.Equals(customer.CustEmail)).ToList();
            if (checkEmail.Count() > 0)
            {
                TempData["errorMessage"] = "This is an Existing Email Address! Please Use Another One!";
                return View(customer);
            }
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Login));
            }
            return View(customer);
        }

        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.Id == id);
        }
    }
}
