﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Producks.Web.Helpers;
using Producks.Web.Models;
using Producks.Web.ViewModels;
using Producks.Data;
using Microsoft.EntityFrameworkCore;

namespace Producks.Web.Controllers
{
    public class CartController : Controller
    {
        private readonly StoreDb _context;
        private IEnumerable<string> repoBrands;
        private IEnumerable<string> repoCategories;

        public CartController(StoreDb context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            if (ViewBag.cart != null)
            {
                ViewBag.total = cart.Sum(item => item.Product.Price * item.quantity);
            }

            return View();
        }
        private int isExist (int id)
        {
            List<Item> cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            for (int i = 0; i < cart.Count; i++)
            {
                if (cart[i].Product.Id.Equals(id))
                {
                    return i;
                }
            }
            return -1;
        }

        public  IActionResult Buy(int id)
        {
            var product = _context.Products
                .Where(x=>x.Id == id).Select(x => new ProductCartVM {
                    ProductId = x.Id,
                    ProductName = x.Name,
                    ProductPrice = x.Price,
                });
            if (product == null)
            {
                return NotFound();
            }
            ProductCart ProductCart = new ProductCart
            {
                Id = product.Single().ProductId,
                Name = product.Single().ProductName,
                Price = product.Single().ProductPrice
            }; 
            if(SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart") == null)
            {
                List<Item> cart = new List<Item>();
                cart.Add(new Item { Product = ProductCart, quantity = 1 });
                SessionHelper.SetObjectAsJson(HttpContext.Session, "cart", cart);

            }
            else
            {
                List<Item> cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
                int index = isExist(id);
                if (index != -1)
                {
                    cart[index].quantity++;
                }
                else
                {
                    cart.Add(new Item { Product = ProductCart, quantity = 1 });

                }
                SessionHelper.SetObjectAsJson(HttpContext.Session, "cart", cart);

            }
            return RedirectToAction("Index");

        }

        public IActionResult Remove(int id)
        {
            List<Item> cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            int index = isExist(id);
            cart.RemoveAt(index);
            SessionHelper.SetObjectAsJson(HttpContext.Session, "cart", cart);
            return RedirectToAction("Index");

        }
    }
}
