﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Producks.Web.Helpers;
using Producks.Web.Models;
using Producks.Data;
using Microsoft.AspNetCore.Http;

namespace Producks.Web.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly StoreDb _context;

        public CheckoutController(StoreDb context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            ViewBag.total = cart.Sum(item => item.Product.Price * item.quantity);
            return View();
        }

        public IActionResult Create()
        {
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            var orderdb = _context.Orders;
            ViewBag.cart = cart;
            ViewBag.total = cart.Sum(item => item.Product.Price * item.quantity);
            string userid = HttpContext.Session.GetString("userid");
            Order order = new Order
            {
                CustId = int.Parse(userid),
                TotalPrice = ViewBag.total,
                Order_Date = DateTime.Now,
                Order_Status = "Pending",
                Delivery_Date = null

            };
            _context.Add(order);
            _context.SaveChanges();
            return RedirectToAction("Detail");
        }

        public IActionResult Detail()
        {
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            var lastestorder = _context.Orders
                .OrderByDescending(a => a.Id)
                .First();
            ViewBag.total = cart.Sum(item => item.Product.Price * item.quantity);
            foreach (var item in ViewBag.cart)
            {
                OrderDetail orderdetail = new OrderDetail
                {
                    OrderId = lastestorder.Id,
                    ProductId = item.Product.Id,
                    quantity = item.quantity
                };
                _context.Add(orderdetail);
                _context.SaveChanges();
            }
            HttpContext.Session.Remove("cart");
            return RedirectToAction("Index", "ProductsCustomerView");
        }
    }
}
