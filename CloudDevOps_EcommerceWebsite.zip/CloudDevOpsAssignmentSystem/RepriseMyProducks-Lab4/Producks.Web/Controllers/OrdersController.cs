﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Producks.Data;

namespace Producks.Web.Controllers
{
    public class OrdersController : Controller
    {
        private readonly StoreDb _context;

        public OrdersController(StoreDb context)
        {
            _context = context;
        }

        // GET: Orders
        public async Task<IActionResult> Index()
        {
            return View(await _context.Orders.Include(c => c.Customer).ToListAsync());
        }

        // GET: Pending Orders
        public async Task<IActionResult> IndexPending()
        {
            return View(await _context.Orders.Include(c => c.Customer).Where(o => o.Order_Status.Equals("Pending")).ToListAsync());
        }

        // GET: Ready to Dispatch Orders
        public async Task<IActionResult> IndexReadyToDispatch()
        {
            return View(await _context.Orders.Include(c => c.Customer).Where(o => o.Order_Status.Equals("Ready To Dispatch")).ToListAsync());
        }

        // GET: Dispatched Orders
        public async Task<IActionResult> IndexDispatched()
        {
            return View(await _context.Orders.Include(c => c.Customer).Where(o => o.Order_Status.Equals("Dispatched")).ToListAsync());
        }

        // GET: Cancelled Orders
        public async Task<IActionResult> IndexCancelled()
        {
            return View(await _context.Orders.Include(c => c.Customer).Where(o => o.Order_Status.Equals("Cancelled")).ToListAsync());
        }

        // GET: Orders/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders
                .Include(c => c.Customer)
                .Include(o => o.OrderDetails)
                .ThenInclude(p => p.Product)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // GET: Orders/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Orders/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CustId,TotalPrice,Order_Date,Order_Status,Delivery_Date")] Order order)
        {
            if (ModelState.IsValid)
            {
                _context.Add(order);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(order);
        }

        // GET: Orders/ReadyToDispatch/5
        public async Task<IActionResult> ReadyToDispatch(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        // POST: Orders/ReadyToDispatch/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReadyToDispatch(int id, [Bind("Id,CustId,TotalPrice,Order_Date,Order_Status,Delivery_Date")] Order order)
        {
            if (id != order.Id)
            {
                return NotFound();
            }

            order.Order_Status = "Ready To Dispatch";

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(order);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderExists(order.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(order);
        }

        // GET: Orders/Dispatch/5
        public async Task<IActionResult> Dispatch(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        // POST: Orders/Dispatch/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Dispatch(int id, [Bind("Id,CustId,TotalPrice,Order_Date,Order_Status,Delivery_Date")] Order order)
        {
            if (id != order.Id)
            {
                return NotFound();
            }

            order.Order_Status = "Dispatched";
            order.Delivery_Date = DateTime.Now;

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(order);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderExists(order.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(order);
        }

        // GET: Orders/Cancel/5
        public async Task<IActionResult> Cancel(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        // POST: Orders/Cancel/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id, [Bind("Id,CustId,TotalPrice,Order_Date,Order_Status,Delivery_Date")] Order order)
        {
            if (id != order.Id)
            {
                return NotFound();
            }

            order.Order_Status = "Cancelled";

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(order);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderExists(order.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(order);
        }

        private bool OrderExists(int id)
        {
            return _context.Orders.Any(e => e.Id == id);
        }
    }
}
