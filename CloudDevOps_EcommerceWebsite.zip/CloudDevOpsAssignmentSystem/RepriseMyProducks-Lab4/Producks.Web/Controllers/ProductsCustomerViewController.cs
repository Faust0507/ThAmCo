﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Producks.Data;
using Producks.Web.ViewModels;
using System.Diagnostics;
using System.Web;
using Producks.Repo;

namespace Producks.Web.Controllers
{
    public class ProductsCustomerViewController : Controller
    {
        private readonly StoreDb _context;
        private IEnumerable<string> repoBrands;
        private IEnumerable<string> repoCategories;

        public ProductsCustomerViewController(StoreDb context)
        {
            _context = context;
            RepoApi rp = new RepoApi(context);
            repoBrands = rp.GetBrandsName();
            repoCategories = rp.GetCategoriesName();
        }

        // GET: ProductsCustomerView
        public ActionResult Index(string prodCat = null, string prodBrand = null, string searchString = "")
        {

            var products = _context.Products.AsEnumerable().Where(p => p.Active)
                .Select(x => new ProductCustomerVM
                {
                    Id = x.Id,
                    Name = x.Name,
                    Description = x.Description,
                    Price = x.Price,
                    StockLevel = x.StockLevel,
                    Brand = x.Brand.Name,
                    Category = x.Category.Name,
                });

            ViewBag.Categories = new SelectList(repoCategories);
            ViewBag.Brands = new SelectList(repoBrands);

            if (!string.IsNullOrEmpty(prodBrand))
            {
                products = products.Where(s => s.Brand.Contains(prodBrand));
            }

            if (!string.IsNullOrEmpty(prodCat))
            {
                products = products.Where(s => s.Category.Contains(prodCat));
            }

            if (!string.IsNullOrEmpty(searchString))
            {
                products = products.Where(s => s.Name.IndexOf(searchString, StringComparison.OrdinalIgnoreCase) >= 0 || s.Description.IndexOf(searchString, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            return View(products);
        }

        // GET: ProductsCustomerView/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            
            var products = await _context.Products
                .Include(r => r.Reviews)
                .ThenInclude(c => c.Customer)
                .Include(od => od.OrderDetails)
                .ThenInclude(o => o.Order)
                .Include(b => b.Brand)
                .Include(c => c.Category)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (products == null)
            {
                return NotFound();
            }

            return View(products);
        }

        // GET: ProductsCustomerView/Create
        public async Task<IActionResult> Create(int? id)
        {
            if (id != null && id > 0)
            {
                var product = _context.Products.Where(i => i.Id == id.Value).Single().Name;

                //var product1 = new SelectList(_context.Products, "Id", "Name", id);
                var prodID = id.Value;  //if use this id comes out, need name
                if (prodID != null)
                {
                    ViewData["ProductId"] = prodID;
                    ViewData["ProductName"] = product;
                    return View();
                }
            }
            return BadRequest("Product ID is null or invalid");
        }

        // POST: ProductsCustomerView/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId,CustId,Description,Review_Date,Active")] Review review)
        {
            review.Review_Date = DateTime.Now;

            if (ModelState.IsValid)
            {
                _context.Add(review);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProductId"] = new SelectList(_context.Products, "Id", "Name", review.ProductId);  //swapped description with name
            return View(review);
        }

        // GET: ProductsCustomerView/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            ViewData["BrandId"] = new SelectList(_context.Brands, "Id", "Name", product.BrandId);
            ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Description", product.CategoryId);
            return View(product);
        }

        // POST: ProductsCustomerView/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CategoryId,BrandId,Name,Description,Price,StockLevel,Active")] Product product)
        {
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BrandId"] = new SelectList(_context.Brands, "Id", "Name", product.BrandId);
            ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Description", product.CategoryId);
            return View(product);
        }

        // GET: ProductsCustomerView/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Brand)
                .Include(p => p.Category)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: ProductsCustomerView/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }
    }
}
