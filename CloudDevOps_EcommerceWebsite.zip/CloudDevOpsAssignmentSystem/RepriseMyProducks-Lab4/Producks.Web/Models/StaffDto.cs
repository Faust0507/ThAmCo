﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Producks.Web.Models
{
    public class StaffDto
    {
        public int StaffId { get; set; }
        public string StaffName { get; set; }
        public string StaffEmail { get; set; }
        public string StaffPassword { get; set; }
        public string StaffRole { get; set; }

        public static IEnumerable<SelectListItem> GetRoleSelectItems()
        {
            yield return new SelectListItem { Text = "Staff", Value = "Staff" };
            yield return new SelectListItem { Text = "Management", Value = "Management" };
        }
    }
}
