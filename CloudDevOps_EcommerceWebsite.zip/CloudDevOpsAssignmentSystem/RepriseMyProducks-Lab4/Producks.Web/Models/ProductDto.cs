﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using Producks.Data;
namespace Producks.Web.Models
{
    public class ProductsDto
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public int BrandId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public int StockLevel { get; set; }
        public bool Active { get; set; }

        public List<Product> Products { get; set; }
        public SelectList Brands { get; set; }
        public SelectList Categories { get; set; }

        public string ProdBrand { get; set; }
        public string ProdCat { get; set; }
        public string SearchString { get; set; }

    }
}
