﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Producks.Web.Models
{
    public class Account
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Contact { get; set; }

        public static IEnumerable<SelectListItem> GetRoleSelectItems()
        {
            yield return new SelectListItem { Text = "Customer", Value = "Customer" };
            yield return new SelectListItem { Text = "Staff", Value = "Staff" };
            yield return new SelectListItem { Text = "Management", Value = "Management" };
        }
    }
}
