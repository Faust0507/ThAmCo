﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Producks.Undercutter.Models
{
    public class Brand
    {
        public int AvailableProductCount { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
